﻿using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RocnikovaPrace.Shapes
{
    public class VertexEllipse
    {
        /// <summary>
        /// Unique number of vertex coresponding to this ellipse.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Bool marking if it's selected by user.
        /// </summary>
        public bool Selected { get; set; }

        /// <summary>
        /// Ellipse that is created when vertex is created.
        /// </summary>
        public Ellipse NewEllipse { get => newEllipse; set => newEllipse = value; }

        private Ellipse newEllipse = new Ellipse()
        {
            Focusable = true,
            Width = 28,
            Height = 28,
            Fill = Brushes.LightBlue,
            Stroke = Brushes.Black,
            StrokeThickness = 2,
            
        };
        public VertexEllipse(int id)
        {
            Id = id;
            newEllipse.Tag = id;
        }
        
        /// <summary>
        /// Method to return newEllipse.
        /// </summary>
        /// <returns></returns>
        public Ellipse CreateEllipse()
        {
            return NewEllipse;  
        }
    }
}
