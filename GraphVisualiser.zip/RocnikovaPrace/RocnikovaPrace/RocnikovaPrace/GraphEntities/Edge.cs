﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RocnikovaPrace.GraphEntities
{
    public class Edge
    {
        public Edge(Vertex from, Vertex to)
        {
            From = from;
            To = to;
            Value = 1;
        }

        /// <summary>
        /// Vertex from which the edge originates.
        /// </summary>
        public Vertex From { get; set; }

        /// <summary>
        /// Vertex where edge goes.
        /// </summary>
        public Vertex To { get; set; }

        /// <summary>
        /// Original vertex used to determin orded of search in dfs.
        /// </summary>
        public Vertex Original { get; set; }

        /// <summary>
        /// Number holding the value of egde.
        /// </summary>
        public double Value { get; set; }   

    }
}
