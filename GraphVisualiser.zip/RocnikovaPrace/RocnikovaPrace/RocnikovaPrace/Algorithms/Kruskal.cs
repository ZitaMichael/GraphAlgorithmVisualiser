﻿using RocnikovaPrace.GraphEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RocnikovaPrace.Algorithms
{
    public class Kruskal
    {
        /// <summary>
        /// Speed at which are steps taken.
        /// </summary>
        public int SearchSpeed { get; set; }

        /// <summary>
        /// List of all edges included in graph.
        /// </summary>
        public List<Edge> AllEdges { get; set; } = new List<Edge>(); 

        /// <summary>
        /// List of all edges necessary to connect every vertex.
        /// </summary>
        public List<Edge> EssentialEdges { get; set; } = new List<Edge>();

        /// <summary>
        /// List of vertices that ahd already been visited.
        /// </summary>
        public List<Vertex> VisitedVertices { get; set; } = new List<Vertex>();
        public Kruskal(int searchSpeed)
        {
            SearchSpeed = searchSpeed;
        }

        /// <summary>
        /// Looks for the coresponding edge and adds it to the EssentialEdges list.
        /// </summary>
        /// <param name="CurrentEdge"></param>
        public void EssentialEdgesAdd(Edge CurrentEdge)
        {
            foreach (Edge edge in AllEdges.ToList()) // 
            {
                if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                {
                    EssentialEdges.Add(edge);
                }
            }
        }

        /// <summary>
        /// Looks for the coresponding edge and removes it from AllEdges list.
        /// </summary>
        /// <param name="CurrentEdge"></param>
        public void AllEdgesRemove(Edge CurrentEdge)
        {
            foreach (Edge edge in AllEdges.ToList())
            {
                if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                {
                    AllEdges.Remove(edge);
                }
            }
        }

        /// <summary>
        /// Runs and performs Kruskal's algorithm on created graph.
        /// </summary>
        /// <param name="vertexEllipseDic"></param>
        /// <param name="edgeLineDic"></param>
        /// <param name="token"></param>
        public async void Run(Dictionary<Vertex, Ellipse> vertexEllipseDic, Dictionary<Edge, Line> edgeLineDic, CancellationToken token)
        {  
            int SoloCounter = 0;

            foreach (Edge edge in edgeLineDic.Keys.ToList())
            {
                AllEdges.Add(edge);
            }
            foreach(Vertex vertex in vertexEllipseDic.Keys.ToList())
            {
                if(vertex.Edges.Count == 0)
                {
                    SoloCounter++;
                }
            }

            while (VisitedVertices.Count != vertexEllipseDic.Keys.Count - SoloCounter)
            {
                if (token.IsCancellationRequested)
                {
                    foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
                    {
                        vertexEllipseDic[vertex].Fill = Brushes.LightBlue;
                        vertex.Visited = false;
                        foreach (Edge edge in vertex.Edges)
                        {
                            edgeLineDic[edge].Stroke = Brushes.Black;
                            edgeLineDic[edge].StrokeThickness = 2;
                            edge.Original = null;
                        }
                    }
                    break;
                }
                if (AllEdges.Count == 0)
                {
                    break;
                }
                Edge CurrentEdge = AllEdges[0];
                foreach (Edge edge in AllEdges)
                {
                    if (edge.Value < CurrentEdge.Value)
                    {
                        CurrentEdge = edge;
                    }
                }

                if (VisitedVertices.Contains(CurrentEdge.To) & VisitedVertices.Contains(CurrentEdge.From))
                 {
                    Queue<Vertex> TestVertices = new Queue<Vertex>();
                    List<Vertex> BlindVertices = new List<Vertex>();
                    Vertex TestVertex = CurrentEdge.To;
                    TestVertices.Enqueue(TestVertex);
                    bool Found = false;
                    while(TestVertices.Count > 0)
                    {
                        if (CurrentEdge.To.Edges.Count == 1)
                        {
                            EssentialEdges.Add(CurrentEdge);
                            foreach (Edge edge in AllEdges.ToList()) // 
                            {
                                if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                                {
                                    EssentialEdges.Add(edge);
                                }
                            }
                            edgeLineDic[CurrentEdge].Stroke = Brushes.DarkGoldenrod;
                            edgeLineDic[CurrentEdge].StrokeThickness = 3;
                            await Task.Delay(SearchSpeed);
                            break;
                        }
                        else if (CurrentEdge.From.Edges.Count == 1)
                        {
                            EssentialEdges.Add(CurrentEdge);
                            foreach (Edge edge in AllEdges.ToList()) // 
                            {
                                if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                                {
                                    EssentialEdges.Add(edge);
                                }
                            }
                            edgeLineDic[CurrentEdge].Stroke = Brushes.DarkGoldenrod;
                            edgeLineDic[CurrentEdge].StrokeThickness = 3;
                            await Task.Delay(SearchSpeed);
                            break;
                        }
                        foreach (Edge edge in TestVertex.Edges.ToList())
                        {
                            foreach(Edge e in EssentialEdges)
                            {
                                if (edge.To == e.To & edge.From == e.From)
                                {
                                    if (!BlindVertices.Contains(edge.To))
                                    {
                                        TestVertices.Enqueue(edge.To);
                                    }
                                }
                            }
                        }
                        if (TestVertex == CurrentEdge.From)
                        {
                            Found = true;
                            TestVertex = TestVertices.Dequeue();
                        }
                        else
                        {
                            BlindVertices.Add(TestVertex);
                            TestVertex = TestVertices.Dequeue();
                        }
                    }
                    if(!Found)
                    {
                        EssentialEdges.Add(CurrentEdge);
                        foreach(Edge edge in AllEdges.ToList()) // 
            {
                            if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                            {
                                EssentialEdges.Add(edge);
                            }
                        }
                        edgeLineDic[CurrentEdge].Stroke = Brushes.DarkGoldenrod;
                        edgeLineDic[CurrentEdge].StrokeThickness = 3;
                        await Task.Delay(SearchSpeed);
                    }
                    Found = false;
                    AllEdges.Remove(CurrentEdge);
                    foreach (Edge edge in AllEdges.ToList())
                    {
                        if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                        {
                            AllEdges.Remove(edge);
                        }
                    }
                    continue;
                }
                else if(VisitedVertices.Contains(CurrentEdge.To) & !VisitedVertices.Contains(CurrentEdge.From))
                {
                    VisitedVertices.Add(CurrentEdge.From);
                    vertexEllipseDic[CurrentEdge.From].Fill = Brushes.Pink;
                    EssentialEdges.Add(CurrentEdge);
                    foreach (Edge edge in AllEdges.ToList()) // 
                    {
                        if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                        {
                            EssentialEdges.Add(edge);
                        }
                    }
                }
                else if(!VisitedVertices.Contains(CurrentEdge.To) & VisitedVertices.Contains(CurrentEdge.From))
                {
                    VisitedVertices.Add(CurrentEdge.To);
                    vertexEllipseDic[CurrentEdge.To].Fill = Brushes.Pink;
                    EssentialEdges.Add(CurrentEdge);
                    foreach(Edge edge in AllEdges.ToList()) // 
            {
                        if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                        {
                            EssentialEdges.Add(edge);
                        }
                    }
                }
                else
                {
                    VisitedVertices.Add(CurrentEdge.From);
                    VisitedVertices.Add(CurrentEdge.To);
                    vertexEllipseDic[CurrentEdge.To].Fill = Brushes.Pink;
                    vertexEllipseDic[CurrentEdge.From].Fill = Brushes.Pink;
                    EssentialEdges.Add(CurrentEdge);
                    foreach(Edge edge in AllEdges.ToList()) // 
            {
                        if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                        {
                            EssentialEdges.Add(edge);
                        }
                    }
                }

                edgeLineDic[CurrentEdge].Stroke = Brushes.DarkGoldenrod;
                edgeLineDic[CurrentEdge].StrokeThickness = 3;


                await Task.Delay(SearchSpeed);
                AllEdges.Remove(CurrentEdge);
                foreach (Edge edge in AllEdges.ToList())
                {
                    if (edge.To == CurrentEdge.From & edge.From == CurrentEdge.To)
                    {
                        AllEdges.Remove(edge);
                    }
                }
            }
            return;
        }
    }
}
