﻿using RocnikovaPrace.GraphEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RocnikovaPrace.Algorithms
{
    public class DFS
    {
        /// <summary>
        /// Starting vertex of algortihgm.
        /// </summary>
        public Vertex Start { get; set; }

        /// <summary>
        /// Previous selected vertex.
        /// </summary>
        public Vertex PreviousVertex { get; set; }

        /// <summary>
        /// Speed at which steps are taken.
        /// </summary>
        public int SearchSpeed { get; set; }

        public DFS(Vertex start, int searchSpeed)
        {
            Start = start;
            SearchSpeed = searchSpeed;  
        }

        /// <summary>
        /// Runs the algorithm on graph created from Start vertex given.
        /// </summary>
        /// <param name="vertexEllipseDic"></param>
        /// <param name="edgeLineDic"></param>
        /// <param name="token"></param>
        public async void Run(Dictionary<Vertex, Ellipse> vertexEllipseDic, Dictionary<Edge, Line> edgeLineDic, CancellationToken token)
        {
            if (Start.Edges.Count == 0)
            {
                return;
            }
            Vertex CurrentVertex = new Vertex();
            Stack<Vertex> s = new Stack<Vertex>();
            Vertex PreviousVertex = new Vertex();

            s.Push(Start);
            vertexEllipseDic[Start].Fill = Brushes.Pink;
            bool FromPrevious = false;
            bool IsFinished = false;

            while (s.Count != 0 )
            {
                if (token.IsCancellationRequested)
                {
                    foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
                    {
                        vertexEllipseDic[vertex].Fill = Brushes.LightBlue;
                        vertex.Visited = false;
                        foreach (Edge edge in vertex.Edges)
                        {
                            edgeLineDic[edge].Stroke = Brushes.Black;
                            edgeLineDic[edge].StrokeThickness = 2;
                            edge.Original = null;
                        }
                    }
                    break;
                }
                PreviousVertex = CurrentVertex;
                CurrentVertex = s.Pop();
                await Task.Delay(200);
                if (!CurrentVertex.Visited)
                {
                    foreach (Edge edge in CurrentVertex.Edges.ToList())
                    {
                        if (!edge.To.Visited)
                        {
                            foreach (Edge edge1 in edge.To.Edges.ToList()) 
                            {
                                if (edge1.To.Id == CurrentVertex.Id & edge1.Original == null)
                                {
                                    edge.Original = CurrentVertex;
                                    edge1.Original = CurrentVertex;
                                }
                            }
                            s.Push(edge.To);
                        }
                        if (edge.To.Id == PreviousVertex.Id & PreviousVertex.Id != null) 
                        {
                            await Task.Delay(SearchSpeed);
                            edgeLineDic[edge].Stroke = Brushes.DarkGoldenrod;
                            edgeLineDic[edge].StrokeThickness = 3;
                            await Task.Delay(SearchSpeed);
                            FromPrevious = true;
                            CurrentVertex.Visited = true;
                            vertexEllipseDic[edge.To].Fill = Brushes.Pink;
                        }
                    }
                    if (!FromPrevious)
                    {
                        foreach (Edge edge in CurrentVertex.Edges.ToList()) 
                        {
                            if (edge.To == edge.Original)
                            {
                                await Task.Delay(SearchSpeed);
                                edgeLineDic[edge].Stroke = Brushes.DarkGoldenrod;
                                edgeLineDic[edge].StrokeThickness = 3;
                                await Task.Delay(SearchSpeed);
                                CurrentVertex.Visited = true;
                                vertexEllipseDic[edge.To].Fill = Brushes.Pink;
                                vertexEllipseDic[CurrentVertex].Fill = Brushes.Pink;
                                break;
                            }
                        }
                    }
                    FromPrevious = false;
                }
                    IsFinished = true;
                vertexEllipseDic[CurrentVertex].Fill = Brushes.Pink;
                CurrentVertex.Visited = true;
                foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
                {
                    if(!vertex.Visited)
                    {
                        IsFinished = false;
                    }
                }
                if(IsFinished)
                {
                    foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
                    {
                        vertex.Visited = false;
                        foreach (Edge edge in vertex.Edges)
                        {
                            edge.Original = null;
                        }
                    }
                    return;
                }
            }
            foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
            {
                vertex.Visited = false;
                foreach (Edge edge in vertex.Edges)
                {
                    edge.Original = null;
                }
            }
            return;
        }
    }
}
