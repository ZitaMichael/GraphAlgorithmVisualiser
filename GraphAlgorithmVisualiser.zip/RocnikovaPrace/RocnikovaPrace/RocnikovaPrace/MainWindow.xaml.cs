﻿using RocnikovaPrace.Algorithms;
using RocnikovaPrace.GraphEntities;
using RocnikovaPrace.Shapes;
using RocnikovaPrace.Visuals;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Shell;
using System.Windows.Threading;

namespace RocnikovaPrace
{
    /// <summary>
    /// Interakční logika pro MainWindow.xaml
    /// </summary>
    /// Graph algorithm visualisator
    /// Michael Zita
    /// 2022/2023
    /// Ročníková práce
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        /// <summary>
        /// Starting vertex of new edge
        /// </summary>
        Vertex newEdgeStart = new Vertex();

        /// <summary>
        /// Ending vertex of new edge
        /// </summary>
        Vertex newEdgeEnd = new Vertex();

        /// <summary>
        /// Starting vertex of selected algorithm
        /// </summary>
        Vertex StartVertex = new Vertex();

        /// <summary>
        /// Time between steps in running algorithm
        /// </summary>
        int SearchSpeed = 600;

        /// <summary>
        /// Total number of vertices created
        /// </summary>
        int VertexCount = 0;

        /// <summary>
        /// New instance of graph, class holding all vertex/edge info
        /// </summary>
        Graph graph = new Graph();

        /// <summary>
        /// Tokensource for cancel token to cancel running algorithm
        /// </summary>
        CancellationTokenSource _tokenSource = null;

        /// <summary>
        /// Dictionary storing each vertexe's ellipse (visualisation of vertex)
        /// </summary>
        Dictionary<Vertex, Ellipse> vertexEllipseDic = new Dictionary<Vertex, Ellipse>();

        /// <summary>
        /// Dictionary storing each edge's line (visualisation of edge)
        /// </summary>
        Dictionary<Edge, Line> edgeLineDic = new Dictionary<Edge, Line>();

        /// <summary>
        /// Dictionary storing each line's value textbox 
        /// </summary>
        Dictionary<Line, TextBox> lineTextBoxDic = new Dictionary<Line, TextBox>();

        /// <summary>
        /// Object that is being passed to be dragged
        /// </summary>
        UIElement dragObject = null;

        /// <summary>
        /// Offset of cursor position to dragged object
        /// </summary>
        Point Offset;

        /// <summary>
        /// Bool checking if new edge is duplicate or not
        /// </summary>
        bool IsDuplicate = false;

        /// <summary>
        /// Bool checking if starting vertex of new edge is selected
        /// </summary>
        bool IsStartSelected = false;
        
        
        /// <summary>
        /// Adds new vertex to graph and resets every vertex and edge to it's normal color.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Additems(object sender, MouseButtonEventArgs e) // Adding of vertexes if left clicked on canvas
        {

            if (!(e.OriginalSource is Ellipse) & Keyboard.IsKeyDown(Key.LeftCtrl)) // If condition met creates new vertex on clicked position
            {
                VertexCount++;

                Vertex vertex = new Vertex(Convert.ToString(VertexCount), Mouse.GetPosition(MyCanvas).X - 12, Mouse.GetPosition(MyCanvas).Y - 12);
                VertexEllipse vertexEllipse = new VertexEllipse(VertexCount);

                Ellipse newEllipse = vertexEllipse.CreateEllipse();  // Creates new ellipse on canvas on position clicked
                Canvas.SetLeft(newEllipse, Mouse.GetPosition(MyCanvas).X - 12);
                Canvas.SetTop(newEllipse, Mouse.GetPosition(MyCanvas).Y - 12);

                newEllipse.PreviewMouseLeftButtonDown += newEllipse_PreviewMouseLeftButtonDown;
                newEllipse.MouseEnter += newEllipse_MouseEnter;
                newEllipse.MouseLeave += newEllipse_MouseLeave;
                newEllipse.MouseLeftButtonUp += newEllipse_MouseLeftButtonUp;
                newEllipse.MouseLeftButtonDown += newEllipse_MouseLeftButtonDown;
                Canvas.SetZIndex(newEllipse, 3); // Sets z index so ellipses overlap lines

                MyCanvas.Children.Add(newEllipse);

                graph.AddVertex(vertex);
                vertexEllipseDic[vertex] = newEllipse;
            }

            foreach (Vertex vertex in vertexEllipseDic.Keys) // If clicked outside of existing ellipses deselects and resets all existing vertices
            {
                vertex.Selected = false;
                vertex.Visited = false;
                vertexEllipseDic[vertex].Fill = Brushes.LightBlue;
                StartVertex = new Vertex();
            } 
            foreach (Edge edge in edgeLineDic.Keys.ToList()) // Resets each edge
            {
                edgeLineDic[edge].StrokeThickness = 2;
                edgeLineDic[edge].Stroke = Brushes.Black;
            }
           IsStartSelected = false;
            if (_tokenSource != null) // If algorithm is running sends canecel token to cancel it
            {
                _tokenSource.Cancel();
            }
            foreach(TextBox textBox in lineTextBoxDic.Values.ToList())
            {
                if(textBox.IsKeyboardFocused) // Defocuses all focused textboxes
                {
                    textBox.Focusable = false;
                }
                else if(textBox.Text.Length == 0)
                {

                    foreach (Line line in lineTextBoxDic.Keys.ToList())
                    {
                        if (lineTextBoxDic[line] == textBox)
                        {
                            foreach (Edge edge in edgeLineDic.Keys.ToList())
                            {
                                if (edgeLineDic[edge] == line)
                                {
                                    textBox.Text = Convert.ToString(edge.Value); // Edits textbox value to match the edge value by looking for the correct edge
                                    textBox.CaretIndex = textBox.Text.Length;
                                }
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Changes ellipse's fill color to red.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void newEllipse_MouseLeftButtonDown(object sender, MouseButtonEventArgs e) // Paints vertex red on click
        {
            Ellipse ActiveEllipse = (Ellipse)e.OriginalSource;
            ActiveEllipse.Fill = Brushes.Red;
        }

        /// <summary>
        /// Changes the vertex's Selected property based on it's pre clicled value.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void newEllipse_MouseLeftButtonUp(object sender, MouseButtonEventArgs e) 
        {
            Ellipse ActiveEllipse = (Ellipse)e.OriginalSource;
            ActiveEllipse.Fill = Brushes.Red;
            foreach (Vertex vertex in vertexEllipseDic.Keys)
            {
                if (vertex.Id == Convert.ToString(ActiveEllipse.Tag)) // Looks for correct vertex, if correct is found, selects it if not deselects it and repaints to light blue
                {
                    vertex.Selected = true;
                }
                else
                {
                    vertex.Selected = false;
                    vertexEllipseDic[vertex].Fill = Brushes.LightBlue;
                }
            }
        }

        /// <summary>
        /// If clicked on ellipse it's marked as start vertex of new edge or if start vertex is already selected it creates new edge between the start vertex and clicked one.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void MyCanvas_PreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e) 
        {
            if (e.OriginalSource is Ellipse & !IsStartSelected) // If rightclicked on ellipse and start is not selected finds the clicked vertex, selects it and makes it new edge start
            {
                Ellipse ActiveEllipse = (Ellipse)e.OriginalSource;

                foreach (Vertex vertex in vertexEllipseDic.Keys)
                {
                    if (vertex.Id == Convert.ToString(ActiveEllipse.Tag))
                    {
                        ActiveEllipse.Fill = Brushes.Purple;
                        newEdgeStart = vertex;
                        IsStartSelected = true;
                        
                    }
                }
            }
            else if(e.OriginalSource is Ellipse & IsStartSelected & !Keyboard.IsKeyDown(Key.LeftCtrl)) // If clicked on ellipse and start vertex is already selected while not holding ctrl down
            {                                                                                          // Creates new edge from start vertex to the vertex clicked
                Ellipse ActiveEllipse = (Ellipse)e.OriginalSource;
                foreach (Vertex vertex in vertexEllipseDic.Keys)
                {
                    if (vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Id != newEdgeStart.Id)
                    {
                        ActiveEllipse.Fill = Brushes.Purple;    
                        newEdgeEnd = vertex;
                    }
                }
                
                    foreach (Vertex vertex in vertexEllipseDic.Keys) // Repaints selected vertices to light blue
                    {
                        if (vertex.Id == newEdgeStart.Id | vertex.Id == newEdgeEnd.Id)
                        {
                            vertexEllipseDic[vertex].Fill = Brushes.LightBlue;
                        }
                    }
                    if (newEdgeStart.Id != newEdgeEnd.Id & newEdgeStart.Id != null & newEdgeEnd.Id != null) // Checks if new edge starting vertex isn't same as ending vertex
                    {
                        Edge edge = new Edge(newEdgeStart, newEdgeEnd);
                        foreach (Edge ed in edgeLineDic.Keys.ToList())
                        {
                            if ((edge.To == ed.To & edge.From == ed.From) | (edge.From == ed.To & edge.To == ed.From)) // Checks if there isn't same edge already
                            {
                                IsDuplicate = true;
                            }
                        }
                        if (!IsDuplicate) // If there is no such edge creates a new one
                        {
                            Line edgeLine = new Line() // Creates visual representation of edge (line)
                            {
                                StrokeThickness = 2,
                                Stroke = Brushes.Black,
                                X1 = newEdgeStart.Left + 14,
                                Y1 = newEdgeStart.Top + 14,
                                X2 = newEdgeEnd.Left + 14,
                                Y2 = newEdgeEnd.Top + 14,
                                Tag = newEdgeStart.Id,
                            };
                        TextBox edgeTextBox = new TextBox() //  Creates text boxes to show and manipulate with edge valeus
                        {
                            FontSize = 11,
                            FontFamily = new FontFamily("/Fonts/#Poppins"),
                            Foreground = Brushes.Black,
                            Text = Convert.ToString(edge.Value),
                            BorderBrush = Brushes.White,
                        };
                        edgeTextBox.MouseEnter += edgeTextBox_MouseEnter;
                        edgeTextBox.TextChanged += edgeTextBox_TextChanged;
                        edgeTextBox.LostKeyboardFocus += edgeTextBox_LostKeyboardFocus;
                        MyCanvas.Children.Add(edgeTextBox);
                        Canvas.SetLeft(edgeTextBox, (edgeLine.X1 + edgeLine.X2)/2); // Sets position of textbox to center x position of matching line and pushes it +10 y position on y axis
                        Canvas.SetTop(edgeTextBox, ((edgeLine.Y1 + edgeLine.Y2) / 2) - 20);
                        if((bool)edgeValueCheckBox.IsChecked) // Checks if user want edge values to be displayed or not and sets it accordingly
                        {
                            edgeTextBox.IsEnabled = false;
                        }
                        else
                        {
                            edgeTextBox.IsEnabled = true;   
                        }
                        edgeLine.PreviewMouseRightButtonDown += edgeLine_PreviewRightButtonDown;
                        Canvas.SetZIndex(edgeLine, 1); // Sets z index lower than ellipses so it goes below them
                        lineTextBoxDic[edgeLine] = edgeTextBox; // Adds it to all lists and dictionaries necessary
                        edgeLineDic[edge] = edgeLine;
                        
                        MyCanvas.Children.Add(edgeLine);
                        newEdgeStart.Edges.Add(edge);

                        Edge temp = new Edge(newEdgeEnd, newEdgeStart);
                        edgeLineDic[temp] = edgeLine;
                        newEdgeEnd.Edges.Add(temp);

                        graph.AddEdge(newEdgeStart, newEdgeEnd);
                        newEdgeStart = new Vertex() { }; // Sets all values to their default
                        newEdgeEnd = new Vertex() { };
                        IsStartSelected = false;
                        IsDuplicate = false;
                        }
                        else if (IsDuplicate) // If same edge exists already then none is created and deselects new edge start vertex 
                        {
                        newEdgeStart = new Vertex() { };
                        newEdgeEnd = new Vertex() { };
                        IsStartSelected = false;
                        IsDuplicate = false;
                        }
                    }
                    else // If new edge start and end are the same vertex it resets them and deselects start
                    {
                    IsStartSelected = false;
                    newEdgeStart = new Vertex();
                    newEdgeEnd = new Vertex();
                    }
                
            }
        }

        /// <summary>
        /// Checks if textBox is equal to zero and if so changes it to default value.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void edgeTextBox_LostKeyboardFocus(object sender, KeyboardEventArgs e)
        {
            TextBox textBox = sender as TextBox;
            if(Convert.ToInt32(textBox.Text) == 0)
            {
                foreach(Line line in lineTextBoxDic.Keys.ToList())
                {
                    if(lineTextBoxDic[line] == textBox)
                    {
                        foreach(Edge edge in edgeLineDic.Keys.ToList())
                        {
                            if (edgeLineDic[edge] == line)
                            {
                                edge.Value = 1;
                                textBox.Text = "1";
                            }
                        }
                    }
                }
                    
            }
        }

        /// <summary>
        /// Checks if the text box input is valid and if so it changes the edge's Value property to the value typed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void edgeTextBox_TextChanged(object sender, TextChangedEventArgs e) 
        {
            TextBox textBox = e.OriginalSource as TextBox;
            bool IsValid = true;
            foreach (Char c in textBox.Text) // If new value is being put in edge value textbox it checks if it is number or not
            {
                if (c < '0' | c > '9')
                {
                    IsValid = false;
                }
            }
            if (IsValid) // If it indeed is number it sets edge value to entered amount and moves caret index to right (on which place in number is keyboard focused
            {
                foreach (Line line in lineTextBoxDic.Keys.ToList())
                {
                    if (lineTextBoxDic[line] == textBox)
                    {
                        foreach (Edge edge in edgeLineDic.Keys.ToList())
                        {
                            if (edgeLineDic[edge] == line)
                            {
                                if (textBox.Text.Length > 0) 
                                {
                                    edge.Value = Convert.ToDouble(textBox.Text);
                                    textBox.CaretIndex = textBox.Text.Length;
                                }
                            }
                        }
                    }
                }
            }
            else // If value entered is not number is resets that textbox text to last valid edge value and moves the caret index to right
            {
                foreach (Line line in lineTextBoxDic.Keys.ToList()) 
                {
                    if (lineTextBoxDic[line] == textBox)
                    {
                        foreach(Edge edge in edgeLineDic.Keys.ToList())
                        {
                            if (edgeLineDic[edge] == line)
                            {
                                textBox.Text = Convert.ToString(edge.Value);
                                textBox.CaretIndex = textBox.Text.Length;
                            }
                        }
                    }
                }
            }
            return;
        }

        /// <summary>
        /// Makes the edge value text box focusable when entered.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void edgeTextBox_MouseEnter(object sender, MouseEventArgs e)
        {
            TextBox textBox = e.OriginalSource as TextBox; // If cursor moves on edge value textbox, it becomes focusable
            textBox.Focusable = true;
        }


        /// <summary>
        /// Checks if ellipse entered is Selected or if it's color is different to light blue if it is the color doesn't change, if it's not it changes to red.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void newEllipse_MouseEnter(object sender, MouseEventArgs e)
        {
            Ellipse ActiveEllipse = (Ellipse)e.OriginalSource; 
            bool marked = false;
            foreach (Vertex vertex in vertexEllipseDic.Keys) // If mouse enter ellipse that is selected or choosen as start of new edge it keeps the color
            {
                if (vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Selected | vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Id == newEdgeStart.Id | vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Id == newEdgeEnd.Id)
                {
                    marked = true;

                }
                else if(ActiveEllipse.Fill == Brushes.Pink)
                {
                    marked = true;
                }
            }
            if (!marked) // if the ellipse is lightblue it changes to red
            {
                ActiveEllipse.Fill = Brushes.Red;
            }

        }

        /// <summary>
        /// Checks if ellipse entered is Selected or if it's color is different to light blue if it is the color doesn't change, if it's not it changes to light blue.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void newEllipse_MouseLeave(object sender, MouseEventArgs e)
        {
            Ellipse ActiveEllipse = (Ellipse)e.OriginalSource;
            bool marked = false;
            foreach (Vertex vertex in vertexEllipseDic.Keys) // When mouse leaves ellipse that is selected or choosen as start of new edge it keeps the color
            {
                if (vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Selected | vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Id == newEdgeStart.Id | vertex.Id == Convert.ToString(ActiveEllipse.Tag) & vertex.Id == newEdgeEnd.Id)
                {
                    marked = true;
                }
                else if (ActiveEllipse.Fill == Brushes.Pink)
                {
                    marked = true;
                }
            }
            if(!marked) // If its unselected red ellipse it changes color back to light blue
            {
                ActiveEllipse.Fill = Brushes.LightBlue;
            }
        }


        /// <summary>
        /// Passes the clicked object as dragObject to be dragged on MouseMove.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void newEllipse_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            this.dragObject = sender as UIElement; // when mouse is pressed on ellipse and dragging begins the object dragObject is set to the object clicked 
            this.Offset = e.GetPosition(this.MyCanvas); // Offset gets the position of our cursor deducts the x and y coordinates of the dragging object
            this.Offset.Y -= Canvas.GetTop(this.dragObject);
            this.Offset.X -= Canvas.GetLeft(this.dragObject);
            this.MyCanvas.CaptureMouse();
            Ellipse ActiveEllipse = (Ellipse)e.OriginalSource;
            ActiveEllipse.Fill = Brushes.Red; // Changes color of ellipse to red
        }

        /// <summary>
        /// Removes clicked vertex and all it's edges.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RemoveItems(object sender, MouseButtonEventArgs e)
        {
            if (e.OriginalSource is Ellipse & Keyboard.IsKeyDown(Key.LeftCtrl)) // if ellipse is right clicked while ctrl is being pressed it goes through
            {                                                                   // all vertexes in vertexEllipseDic to find coresponding vertex to then go through its edges and remove each of them and their counterparts
                Ellipse ActiveVertexEllipse = (Ellipse)e.OriginalSource;
                foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
                {
                    if (vertex.Id == Convert.ToString(ActiveVertexEllipse.Tag))
                    {
                        foreach(Edge edge in vertex.Edges.ToList())
                        {
                            MyCanvas.Children.Remove(edgeLineDic[edge]);
                            MyCanvas.Children.Remove(lineTextBoxDic[edgeLineDic[edge]]);
                            lineTextBoxDic.Remove(edgeLineDic[edge]);
                            graph.RemoveEdge(edge.From, edge.To);
                            edgeLineDic.Remove(edge);
                            foreach(Edge tmp in edge.To.Edges.ToList()) // Deletes each edges counterpart (the edge from the opposite vertex to the one being clicked).
                            {
                                if(tmp.To == edge.From & tmp.From == edge.To)
                                {
                                    edge.To.Edges.Remove(tmp);
                                    edgeLineDic.Remove(tmp);
                                }
                            }
                        }
                        vertex.Edges = new List<Edge>(); // Creates blank list of edges and then removes vertex from all storages.

                        graph._elementDic.Remove(vertex);
                        vertexEllipseDic.Remove(vertex);
                        graph.RemoveVertex(vertex);
                        MyCanvas.Children.Remove(ActiveVertexEllipse);
                    }
                 

                }
            }
        }

        /// <summary>
        /// Unchecks all other radio buttons.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dfsButton_Checked(object sender, RoutedEventArgs e)
        {
            bfsButton.IsChecked = false; // Unchecks other radio buttons.
            kruskalButton.IsChecked = false;
        }

        /// <summary>
        /// Unchecks all other radio buttons.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void bfsButton_Checked(object sender, RoutedEventArgs e)
        {
            dfsButton.IsChecked = false; // Unchecks other radio buttons.
            kruskalButton.IsChecked= false; 
        }

        /// <summary>
        /// Unchecks all other radio buttons.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void kruskalButton_Checked(object sender, RoutedEventArgs e)
        {
            dfsButton.IsChecked = false; // Unchecks other radio buttons.
            bfsButton.IsChecked = false;

        }

        /// <summary>
        /// Checks the bfs button as default on load setting.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            bfsButton.IsChecked = true; // Checks bfs button by default.
        }
 

        /// <summary>
        /// Runs the selected algorithm.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            _tokenSource = new CancellationTokenSource(); // Creates new cancellationTokenSource that can be passed in case user wants to stop running algorithm.
            var token = _tokenSource.Token;

            if(bfsButton.IsChecked == true) // If bfs algorithm is selected it goes through all vertexes to find the selected one and sets it as starting point.
            {
                foreach( Vertex vertex in vertexEllipseDic.Keys.ToList())
                {
                    if (vertex.Selected)
                    {
                        StartVertex = vertex;
                    }
                }
                if(StartVertex.Id == null)
                {
                    MessageBox.Show("You need to select a starting vertex by left clicking it.","Warning");
                }
                BFS bfs = new BFS(StartVertex, SearchSpeed); // Then creates new instance of the algorithm class and runs the algorithm itself.
                bfs.Run(vertexEllipseDic, edgeLineDic, token);
            }
            else if (dfsButton.IsChecked == true) // If dfs algorithm is selected it goes throught all vertexes to find the selected one and sets it as starting point.
            {
                foreach (Vertex vertex in vertexEllipseDic.Keys.ToList())
                {
                    if (vertex.Selected)
                    {
                        StartVertex = vertex;
                    }
                }
                if (StartVertex.Id == null)
                {
                    MessageBox.Show("You need to select a starting vertex by left clicking it.", "Warning");
                }
                DFS dfs = new DFS(StartVertex, SearchSpeed); // Then creates new instance of the algorithm class and runs the algorithm itself.
                dfs.Run(vertexEllipseDic, edgeLineDic, token);
            }
            else if(kruskalButton.IsChecked == true)
            {
                Kruskal kruskal = new Kruskal(SearchSpeed); // Checks if Kruskal's algorithm is selected and if so it creates new instance of the algorithm's class and runs it.
                kruskal.Run(vertexEllipseDic, edgeLineDic, token);
            }
        }

        /// <summary>
        /// Changes the dragObject's and all of it's belonging objects (lines) coordinates so it matches the movement of cursor.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MyCanvas_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            if (this.dragObject == null) // If mouse moves and no object is dragging it returns.

                return;

            if (e.GetPosition(sender as IInputElement).X < MyCanvas.ActualWidth - 1 && e.GetPosition(sender as IInputElement).Y < MyCanvas.ActualHeight - 1 && e.GetPosition(sender as IInputElement).X > 1 && e.GetPosition(sender as IInputElement).Y > 1)
            { 
                if (dragObject is Ellipse)
                {
                    var position = e.GetPosition(sender as IInputElement); // If object sent is inside of our workspace (MyCanvas) it changes its coordinates to match the cursor.

                    Canvas.SetTop(this.dragObject, position.Y - this.Offset.Y);

                    Canvas.SetLeft(this.dragObject, position.X - this.Offset.X);

                    Ellipse ActiveEllipse = (Ellipse)dragObject;
                    foreach (Vertex vertex in vertexEllipseDic.Keys) // Creates new ellipse matching the dragObject ellipse being sent and then goes through all vertices to find coresponding one
                    {
                        if (vertex.Id == Convert.ToString(ActiveEllipse.Tag))
                        {
                            vertex.Left = Canvas.GetLeft(ActiveEllipse); // It changes the vertex property to its ellipse actual coordinates.
                            vertex.Top = Canvas.GetTop(ActiveEllipse);
                            if (vertex.Edges.Count() != 0)
                            {
                                foreach (Edge edge in vertex.Edges)
                                {
                                    if (edgeLineDic[edge].Tag == vertex.Id) // It goes through all edges of dragged vertex and checks if its tag matches vertex's id (each line has its starting vertex's id in Tag property)
                                    {                                       // and if so it moves its X1 and Y1 coordinates to stay in ellipse.
                                        edgeLineDic[edge].X1 = Canvas.GetLeft(dragObject) + 14;
                                        edgeLineDic[edge].Y1 = Canvas.GetTop(dragObject) + 14;
                                        Canvas.SetLeft(lineTextBoxDic[edgeLineDic[edge]], ((edgeLineDic[edge].X1 + edgeLineDic[edge].X2)/2));
                                        Canvas.SetTop(lineTextBoxDic[edgeLineDic[edge]], ((edgeLineDic[edge].Y1 + edgeLineDic[edge].Y2) / 2) - 20);
                                    }
                                    else // If it doesn't match it moves the X2 and Y2 coordinates .
                                    {
                                        edgeLineDic[edge].X2 = Canvas.GetLeft(dragObject) + 14;
                                        edgeLineDic[edge].Y2 = Canvas.GetTop(dragObject) + 14;
                                        Canvas.SetLeft(lineTextBoxDic[edgeLineDic[edge]], ((edgeLineDic[edge].X1 + edgeLineDic[edge].X2) / 2));
                                        Canvas.SetTop(lineTextBoxDic[edgeLineDic[edge]], ((edgeLineDic[edge].Y1 + edgeLineDic[edge].Y2) / 2) - 20);
                                    }
                                }
                            }

                        }
                    }
                }
            }
            else
            {
                this.dragObject = null; // If dragObject is our of workspace it's set to null.
            }

        }

        /// <summary>
        /// Changes dragObject to null.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MyCanvas_PreviewMouseUp(object sender, MouseButtonEventArgs e)
        {

                this.dragObject = null; // When released the drag object is changed to null and mouse capture is released.
                this.MyCanvas.ReleaseMouseCapture();
        
        }

        /// <summary>
        /// Removes the clicked line and coresponding edges.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void edgeLine_PreviewRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            bool Removed = false; 
            Line ActiveLine = (Line)e.OriginalSource;
            foreach (Edge edge in edgeLineDic.Keys.ToList()) // If line is right clicked it goes through edgeLineDic to find coresponding edge and removes line and both edges of that line.
            {
                if (edgeLineDic[edge] == ActiveLine)
                {
                    if (!Removed)
                    {
                        MyCanvas.Children.Remove(lineTextBoxDic[ActiveLine]);
                        lineTextBoxDic.Remove(ActiveLine);
                        Removed = true;
                    }
                    MyCanvas.Children.Remove(edgeLineDic[edge]);
                    graph.RemoveEdge(edge.From, edge.To);
                    edgeLineDic.Remove(edge);
                    edge.From.Edges.Remove(edge);

                    Edge temp = new Edge(edge.To, edge.From);
                    edgeLineDic.Remove(temp);
                    edge.To.Edges.Remove(temp);
                }
            }
        }
        
        /// <summary>
        /// Clears whole canvas and removes all vertices and edges.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void clearButton_Click(object sender, RoutedEventArgs e)
        {
            foreach(Line line in lineTextBoxDic.Keys.ToList()) // When clear button is clicked first it goes through and removes all lines
            {
                MyCanvas.Children.Remove(lineTextBoxDic[line]);
                lineTextBoxDic.Remove(line);
            }
            foreach (Vertex vertex in vertexEllipseDic.Keys.ToList()) // Then goes through all vertices and first removes all of their edges and then vertices themselves.
            {
                    foreach (Edge edge in vertex.Edges.ToList())
                    {
                        MyCanvas.Children.Remove(edgeLineDic[edge]);
                        graph.RemoveEdge(edge.From, edge.To);
                        edgeLineDic.Remove(edge);
                        Edge temp = new Edge(edge.To, edge.From);
                        edgeLineDic.Remove(temp);
                        edge.To.Edges.Remove(temp);
                    }
                    MyCanvas.Children.Remove(vertexEllipseDic[vertex]);
                    vertex.Edges = new List<Edge>();

                    graph._elementDic.Remove(vertex);
                    vertexEllipseDic.Remove(vertex);
                    graph.RemoveVertex(vertex);
                    VertexCount = 0; // VertexCount is reset.

            }
        }

        /// <summary>
        /// Changes SearchSpeed value to match speedSlider setting.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void speedSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            SearchSpeed = (int)speedSlider.Value; // When speed slider value is changed it's converted to int value SearchSpeed.
        }

        /// <summary>
        /// Makes edge value text boxes hidden and unfocusable.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void edgeValueCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            foreach(TextBox textBox in lineTextBoxDic.Values.ToList()) // When user checks hide all edge's values button it sets every edge textbox to be hidden and unfocusable.
            {
                textBox.IsEnabled = false;
                textBox.Visibility = Visibility.Hidden;
            }
        }

        /// <summary>
        /// Makes edge value text boxes visible and focusable.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void edgeValueCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            foreach (TextBox textBox in lineTextBoxDic.Values.ToList()) // When user unchecks hide all edge's values button is shows every edge textbox and makes it focusable.
            {
                textBox.IsEnabled = true;
                textBox.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// Displays info about controls of application.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void infoImage_MouseDown(object sender, MouseButtonEventArgs e) // If the info image is clicked it displays message box with controls of the app.
        {
            MessageBox.Show("Controls: \nHold left ctrl + left click => Add vertex\nRight click on two vertices => create an edge\nHold left ctrl + right click on vertex => Delete Vertex\nRight click on edge => Delete edge\n\nAlgorithms:\nSelect starting vertex by left clicking it and then press run button\n(Not necessary for Kruskal's algorithm)\nAfter running algorithm, clear vertices by left clicking elsewhere","Help");
        }
    }
}
