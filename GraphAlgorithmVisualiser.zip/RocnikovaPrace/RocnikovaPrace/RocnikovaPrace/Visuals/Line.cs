﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Shapes;

namespace RocnikovaPrace.Visuals
{
    public class EdgeLine
    {
        /// <summary>
        /// X1 coordinate of new coresponding line.
        /// </summary>
        public double X1 { get; set; }

        /// <summary>
        /// Y1 coordinate of new coresponding line.
        /// </summary>
        public double Y1 { get; set; }

        /// <summary>
        /// X2 coordinate of new coresponding line.
        /// </summary>
        public double X2 { get; set; }

        /// <summary>
        /// Y2 coordinate of new coresponding line.
        /// <summary>
        public double Y2 { get; set; }

        public EdgeLine(double x1, double y1, double x2, double y2)
        {
            X1 = x1;
            Y1 = y1;
            X2 = x2;
            Y2 = y2;
        }



    }
}
