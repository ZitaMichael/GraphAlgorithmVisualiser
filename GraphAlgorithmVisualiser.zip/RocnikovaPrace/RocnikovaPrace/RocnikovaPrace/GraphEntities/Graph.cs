﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace RocnikovaPrace.GraphEntities
{
    public class Graph
    {
        /// <summary>
        /// Dictionary of every vertex and is's edges.
        /// </summary>
        public Dictionary<Vertex, IList<Edge>> _elementDic;

        public Graph()
        {
            _elementDic = new Dictionary<Vertex, IList<Edge>>();
        }

        /// <summary>
        /// Adds vertex to _elementDic dictionary.
        /// </summary>
        /// <param name="vertex"></param>
        public void AddVertex(Vertex vertex)
        {
            _elementDic.Add(vertex, new List<Edge>());
        }

        /// <summary>
        /// Adds edge and it's counter edge to _elementDic dictionary to is coresponding vertex.
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public void AddEdge(Vertex from, Vertex to)
        {
            if (from.Id != null & to.Id != null)
            {
                var srcEdge = new Edge(from, to);
                var desEdge = new Edge(to, from);
                _elementDic[from].Add(srcEdge);
                _elementDic[to].Add(desEdge);
            }
        }

        /// <summary>
        /// Returns the number of vertices.
        /// </summary>
        /// <returns></returns>
        public int GetVerticesCount()
        { 
            return _elementDic.Keys.Count;
        }

        /// <summary>
        /// Returns number of edges.
        /// </summary>
        /// <returns></returns>
        public int GetEdgesCount()
        {
            int EdgesCount = 0; 
            foreach(var ListOfEdges in _elementDic.Values)
            {
                foreach(Edge e in ListOfEdges)
                {
                    EdgesCount++;
                }
            }
            EdgesCount /= 2;
            return EdgesCount;
        }

        /// <summary>
        /// Removes selected vertex from _elementDic.
        /// </summary>
        /// <param name="vertex"></param>
        public void RemoveVertex(Vertex vertex)
        {
            foreach (var prvek in _elementDic)
            {
                var edge = GetEdge(prvek.Key, vertex);
                if (edge != null)
                {
                    prvek.Value.Remove(edge);
                }
            }
            _elementDic.Remove(vertex);
        }

        /// <summary>
        /// Returns edge from _elementDic coresponding to vertices given.
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        /// <returns></returns>
        public Edge GetEdge(Vertex from, Vertex to)
        {
            return _elementDic[from].FirstOrDefault(v
                => v.From.Equals(from)
                && v.To.Equals(to)); 
        }

        /// <summary>
        /// Removes edge from _elementDic coresponding to vertices given.
        /// </summary>
        /// <param name="from"></param>
        /// <param name="to"></param>
        public void RemoveEdge(Vertex from, Vertex to)
        {
            foreach (Edge e in from.Edges)
            {
                List<Edge> newList = new List<Edge>();
                if(!(e.From == from & e.To == to))
                {
                    newList.Add(e);
                }
                _elementDic[from] = newList;
            }

            foreach (Edge e in to.Edges)
            {
                List<Edge> newList = new List<Edge>();
                if (!(e.From == to & e.To == from))
                {
                    newList.Add(e);
                }
                _elementDic[to] = newList;
            }
        }      
    }
}
