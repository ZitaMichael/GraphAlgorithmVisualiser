﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RocnikovaPrace.GraphEntities
{
    public class Vertex
    {
        /// <summary>
        /// X coordinate of coresponding ellipse.
        /// </summary>
        public double Left { get; set; }


        /// <summary>
        /// Y coordinate of coresponding ellipse.
        /// </summary>
        public double Top { get; set; }
        public Vertex(string id, double left, double top)
        {
            Id = id;
            Selected = false;
            Left = left;
            Top = top;
            Visited = false;
        }
        public Vertex()
        { }

        /// <summary>
        /// List of all edges going from this vertex.
        /// </summary>
        public List<Edge> Edges = new List<Edge>();

        /// <summary>
        /// Unique number of vertex
        /// </summary>
        public string Id { get; }

        /// <summary>
        /// Bool marking if it's selected by user.
        /// </summary>
        public bool Selected { get; set; }

        /// <summary>
        /// Bool marking if vertex had already been visited durning algorithm search.
        /// </summary>
        public bool Visited { get; set; }
    }
}
