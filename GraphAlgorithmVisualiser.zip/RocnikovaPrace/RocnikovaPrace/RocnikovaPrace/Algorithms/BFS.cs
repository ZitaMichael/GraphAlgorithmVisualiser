﻿using RocnikovaPrace.GraphEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Documents;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RocnikovaPrace.Algorithms
{
    public class BFS
    {
        public Vertex Start { get; set; }   
        public int SearchSpeed { get; set; }
        public BFS(Vertex start, int searchSpeed)
        {
            Start = start;
            SearchSpeed = searchSpeed;  
        }

        public async void Run(Dictionary<Vertex, Ellipse> vertexEllipseDic, Dictionary<Edge, Line> edgeLineDic, CancellationToken token)
        {
            if(Start.Edges.Count == 0)
            {
                return;
            }
            Vertex CurrentVertex = Start;
            Queue<Vertex> q = new Queue<Vertex>();
            q.Enqueue(CurrentVertex);
            vertexEllipseDic[CurrentVertex].Fill = Brushes.Pink;
            await Task.Delay(SearchSpeed);

            while (q.Count != 0)
            {
                if (token.IsCancellationRequested)
                {
                    foreach(Vertex vertex in vertexEllipseDic.Keys.ToList())
                    {
                        vertexEllipseDic[vertex].Fill = Brushes.LightBlue;
                        vertex.Visited = false;
                        foreach(Edge edge in vertex.Edges)
                        {
                            edgeLineDic[edge].Stroke = Brushes.Black;
                            edgeLineDic[edge].StrokeThickness = 2;
                        }
                    }
                    break;
                }
                CurrentVertex.Visited = true;
                CurrentVertex = q.Dequeue();               
                await Task.Delay(200);

                foreach (Edge e in CurrentVertex.Edges.ToList())
                {
                    if(!e.To.Visited)
                    {
                        edgeLineDic[e].Stroke = Brushes.DarkGoldenrod;
                        edgeLineDic[e].StrokeThickness = 3;
                        q.Enqueue(e.To);
                        e.To.Visited = true;
                        await Task.Delay(SearchSpeed);
                        vertexEllipseDic[e.To].Fill = Brushes.Pink;
                        await Task.Delay(SearchSpeed);
                    }
                }
            }
            return;
        }
    }
}
